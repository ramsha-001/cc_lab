﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace GalaxyShooterGame
{
    public class DSLParser
    {
        public GameDefinition Parse(string script)
        {
            var gameDefinition = new GameDefinition();

            foreach (var line in script.Split('\n'))
            {
                if (line.StartsWith("Ship"))
                {
                    gameDefinition.Ships.Add(ParseShip(line));
                }
                else if (line.StartsWith("Enemy"))
                {
                    gameDefinition.Enemies.Add(ParseEnemy(line));
                }
                else if (line.StartsWith("PowerUp"))
                {
                    gameDefinition.PowerUps.Add(ParsePowerUp(line));
                }
            }

            return gameDefinition;
        }

        private Ship ParseShip(string line)
        {
            var regex = new Regex(@"Ship ""(.*?)"" \{ Health = (\d+); Speed = (\d+); Weapon = ""(.*?)""; \}");
            var match = regex.Match(line);

            return new Ship
            {
                Name = match.Groups[1].Value,
                Health = int.Parse(match.Groups[2].Value),
                Speed = int.Parse(match.Groups[3].Value),
                Weapon = match.Groups[4].Value
            };
        }

        private Enemy ParseEnemy(string line)
        {
            var regex = new Regex(@"Enemy ""(.*?)"" \{ Health = (\d+); Speed = (\d+); Pattern = ""(.*?)""; \}");
            var match = regex.Match(line);

            return new Enemy
            {
                Name = match.Groups[1].Value,
                Health = int.Parse(match.Groups[2].Value),
                Speed = int.Parse(match.Groups[3].Value),
                Pattern = match.Groups[4].Value
            };
        }

        private PowerUp ParsePowerUp(string line)
        {
            var regex = new Regex(@"PowerUp ""(.*?)"" \{ Effect = ""(.*?)""; Duration = (\d+); \}");
            var match = regex.Match(line);

            return new PowerUp
            {
                Name = match.Groups[1].Value,
                Effect = match.Groups[2].Value,
                Duration = int.Parse(match.Groups[3].Value)
            };
        }
    }
}
