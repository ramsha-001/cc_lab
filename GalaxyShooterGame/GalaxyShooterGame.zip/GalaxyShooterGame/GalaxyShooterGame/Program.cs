﻿using var game = new GalaxyShooterGame.Game1();
game.Run();
