﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GalaxyShooterGame
{
    public class GameInterpreter
    {
        public void LoadGame(GameDefinition definition, out List<Ship> ships, out List<Enemy> enemies, out List<PowerUp> powerUps)
        {
            ships = definition.Ships;
            enemies = definition.Enemies;
            powerUps = definition.PowerUps;
        }
    }
}
