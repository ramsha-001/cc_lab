﻿using Microsoft.Xna.Framework;
using System.Collections.Generic;
using Microsoft.Xna.Framework.Graphics;

namespace GalaxyShooterGame
{
   

    public class Ship
    {
        public string Name { get; set; }
        public int Health { get; set; }
        public int Speed { get; set; }
        public string Weapon { get; set; }
        public Texture2D Texture { get; set; }

        public void Update(GameTime gameTime)
        {
            // Ship movement logic here
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(Texture, new Vector2(100, 100), Color.White);
        }
    }

    public class Enemy
    {
        public string Name { get; set; }
        public int Health { get; set; }
        public int Speed { get; set; }
        public string Pattern { get; set; }
        public Texture2D Texture { get; set; }

        public void Update(GameTime gameTime)
        {
            // Enemy movement logic based on pattern
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(Texture, new Vector2(200, 200), Color.Red);
        }
    }

    public class PowerUp
    {
        public string Name { get; set; }
        public string Effect { get; set; }
        public int Duration { get; set; }
    }

    public class GameDefinition
    {
        public List<Ship> Ships { get; set; } = new List<Ship>();
        public List<Enemy> Enemies { get; set; } = new List<Enemy>();
        public List<PowerUp> PowerUps { get; set; } = new List<PowerUp>();
    }

}
