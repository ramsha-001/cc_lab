﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
namespace GalaxyShooterGame
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;

        private List<Ship> _ships;
        private List<Enemy> _enemies;
        private List<PowerUp> _powerUps;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            base.Initialize();

            // Load gameplay elements from DSL
            string dslScript = System.IO.File.ReadAllText("game.dsl");
            var parser = new DSLParser();
            var gameDefinition = parser.Parse(dslScript);

            var interpreter = new GameInterpreter();
            interpreter.LoadGame(gameDefinition, out _ships, out _enemies, out _powerUps);
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            // Load textures and assets for ships, enemies, and power-ups
            foreach (var ship in _ships)
            {
                ship.Texture = Content.Load<Texture2D>("ship_hero");
            }

            foreach (var enemy in _enemies)
            {
                enemy.Texture = Content.Load<Texture2D>("enemy_fighter");
            }
        }

        protected override void Update(GameTime gameTime)
        {
            if (Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // Update game objects
            foreach (var ship in _ships)
            {
                ship.Update(gameTime);
            }

            foreach (var enemy in _enemies)
            {
                enemy.Update(gameTime);
            }

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            _spriteBatch.Begin();

            // Draw ships
            foreach (var ship in _ships)
            {
                ship.Draw(_spriteBatch);
            }

            // Draw enemies
            foreach (var enemy in _enemies)
            {
                enemy.Draw(_spriteBatch);
            }

            _spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
