﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab8_DFA
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Define DFA components
            HashSet<string> states = new HashSet<string> { "q0", "q1", "q2", "q3" }; // States
            string startState = "q0"; // Start state
            HashSet<string> finalStates = new HashSet<string> { "q3" }; // Final state

            // Define transitions
            Dictionary<(string, char), string> transitions = new Dictionary<(string, char), string>
            {
                { ("q0", 'a'), "q1" },
                { ("q0", 'b'), "q2" },
                { ("q1", 'c'), "q3" },
                { ("q2", 'd'), "q3" }
            };

            while (true)
            {
                Console.WriteLine("Enter input string (e.g., ac, bd). Type 'exit' to quit:");
                string input = Console.ReadLine();

                // Check if the user wants to exit
                if (input.ToLower() == "exit")
                {
                    Console.WriteLine("Exiting the program...");
                    break;
                }

                // Process input using DFA
                string currentState = startState;
                bool isAccepted = true;

                foreach (char symbol in input)
                {
                    if (transitions.ContainsKey((currentState, symbol)))
                    {
                        currentState = transitions[(currentState, symbol)];
                    }
                    else
                    {
                        Console.WriteLine("Rejected: Invalid transition.");
                        isAccepted = false;
                        break;
                    }
                }

                if (isAccepted && finalStates.Contains(currentState))
                {
                    Console.WriteLine("Accepted: Input matches the grammar.");
                }
                else if (isAccepted)
                {
                    Console.WriteLine("Rejected: Did not reach a final state.");
                }
            }
        }
    }
}
