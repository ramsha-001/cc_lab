﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Q6_LabTerminal
{

    class Program
    {
        static void Main()
        {
            string downloadsPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "\\Downloads\\UserDetails.txt";

            Console.WriteLine("Enter usernames (separated by commas):");
            string input = Console.ReadLine();
            string[] usernames = input.Split(',').Select(u => u.Trim()).ToArray();

            List<string> validUsernames = new List<string>();
            List<string> invalidUsernames = new List<string>();

            StringBuilder results = new StringBuilder();

            foreach (string username in usernames)
            {
                string validationMessage;
                if (ValidateUsername(username, out validationMessage))
                {
                    validUsernames.Add(username);
                    results.AppendLine(GenerateUsernameDetails(username));
                }
                else
                {
                    invalidUsernames.Add(username);
                    results.AppendLine($"{username} - Invalid ({validationMessage})");
                }
            }

            results.AppendLine($"\nSummary:");
            results.AppendLine($"- Total Usernames: {usernames.Length}");
            results.AppendLine($"- Valid Usernames: {validUsernames.Count}");
            results.AppendLine($"- Invalid Usernames: {invalidUsernames.Count}\n");

            if (invalidUsernames.Count > 0)
            {
                results.AppendLine("Invalid Usernames:");
                results.AppendLine(string.Join(", ", invalidUsernames));
            }

            File.WriteAllText(downloadsPath, results.ToString());
            Console.WriteLine($"Results saved to {downloadsPath}");

            Console.WriteLine("Do you want to retry invalid usernames? (y/n):");
            if (Console.ReadLine().ToLower() == "y")
            {
                Console.WriteLine("Enter invalid usernames:");
                string retryInput = Console.ReadLine();
                string[] retryUsernames = retryInput.Split(',').Select(u => u.Trim()).ToArray();

                foreach (string username in retryUsernames)
                {
                    string validationMessage;
                    if (ValidateUsername(username, out validationMessage))
                    {
                        validUsernames.Add(username);
                        results.AppendLine(GenerateUsernameDetails(username));
                        invalidUsernames.Remove(username);
                    }
                    else
                    {
                        results.AppendLine($"{username} - Invalid ({validationMessage})");
                    }
                }

                results.AppendLine($"\nUpdated Summary:");
                results.AppendLine($"- Total Usernames: {usernames.Length + retryUsernames.Length}");
                results.AppendLine($"- Valid Usernames: {validUsernames.Count}");
                results.AppendLine($"- Invalid Usernames: {invalidUsernames.Count}\n");

                File.WriteAllText(downloadsPath, results.ToString());
                Console.WriteLine($"Updated results saved to {downloadsPath}");
            }
        }

        static bool ValidateUsername(string username, out string message)
        {
            if (!Regex.IsMatch(username, "^[a-zA-Z].{4,14}$"))
            {
                message = "Username length must be between 5 and 15";
                return false;
            }

            if (!Regex.IsMatch(username, "^[a-zA-Z][a-zA-Z0-9_]*$"))
            {
                message = "Username must start with a letter and contain only letters, numbers, and underscores";
                return false;
            }

            message = string.Empty;
            return true;
        }

        static string GenerateUsernameDetails(string username)
        {
            int uppercase = username.Count(char.IsUpper);
            int lowercase = username.Count(char.IsLower);
            int digits = username.Count(char.IsDigit);
            int underscores = username.Count(c => c == '_');

            string password = GeneratePassword();
            string strength = EvaluatePasswordStrength(password);

            return $"{username} - Valid\n   Letters: {uppercase + lowercase} (Uppercase: {uppercase}, Lowercase: {lowercase}), Digits: {digits}, Underscores: {underscores}\n   Generated Password: {password} (Strength: {strength})\n";
        }

        static string GeneratePassword()
        {
            Random random = new Random();
            const string upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            const string lower = "abcdefghijklmnopqrstuvwxyz";
            const string digits = "0123456789";
            const string special = "!@#$%^&*";
            const string all = upper + lower + digits + special;

            string password = new string(Enumerable.Repeat(upper, 2).Select(s => s[random.Next(s.Length)]).ToArray()) +
                              new string(Enumerable.Repeat(lower, 2).Select(s => s[random.Next(s.Length)]).ToArray()) +
                              new string(Enumerable.Repeat(digits, 2).Select(s => s[random.Next(s.Length)]).ToArray()) +
                              new string(Enumerable.Repeat(special, 2).Select(s => s[random.Next(s.Length)]).ToArray()) +
                              new string(Enumerable.Repeat(all, 4).Select(s => s[random.Next(s.Length)]).ToArray());

            return new string(password.OrderBy(c => random.Next()).ToArray());
        }

        static string EvaluatePasswordStrength(string password)
        {
            if (password.Length >= 12 &&
                password.Count(char.IsUpper) >= 2 &&
                password.Count(char.IsLower) >= 2 &&
                password.Count(char.IsDigit) >= 2 &&
                password.Count(c => "!@#$%^&*".Contains(c)) >= 2)
            {
                return "Strong";
            }
            return "Medium";
        }
    }


}
