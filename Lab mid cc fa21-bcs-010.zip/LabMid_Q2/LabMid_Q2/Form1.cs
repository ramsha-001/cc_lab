﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabMid_Q2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGeneratePassword_Click(object sender, EventArgs e)
        {
            // Get user inputs
            string registrationNumber = txtRegistrationNumber.Text; // Registration number input
            string firstName = txtFirstName.Text;                  // First name input
            string lastName = txtLastName.Text;                    // Last name input
            string favoriteMovie = txtFavoriteMovie.Text;          // Favorite movie input

            // Extract required components based on the rules
            string[] parts = registrationNumber.Split('-');
            string digitsFromReg = parts[2].Substring(parts[2].Length - 2); // Get the last 2 digits from "010"

            char secondLetterFirstName = firstName.Length > 1 ? firstName[1] : 'X';  // 'a' or 'X' if not available
            char secondLetterLastName = lastName.Length > 1 ? lastName[1] : 'Y';    // 'o' or 'Y' if not available
            string charsFromMovie = favoriteMovie.Length > 1 ? favoriteMovie.Substring(0, 2) : "ZZ"; // "Da" or "ZZ" if not available

            // Define a pool of special characters, excluding '#'
            string specialCharacters = "!@$%^&*()-_=+[]{};:'\",.<>?/|\\`~";

            // Generate random special character from the pool
            Random rand = new Random();
            char randomSpecialChar = specialCharacters[rand.Next(specialCharacters.Length)];

            // Create the initial password parts
            string password = $"{digitsFromReg}{secondLetterFirstName}{secondLetterLastName}{charsFromMovie}{randomSpecialChar}";

            // Fill the remaining length with random alphanumeric characters
            int remainingLength = 14 - password.Length;
            string alphanumeric = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

            StringBuilder finalPassword = new StringBuilder(password);
            for (int i = 0; i < remainingLength; i++)
            {
                finalPassword.Append(alphanumeric[rand.Next(alphanumeric.Length)]);
            }

            // Ensure password meets all criteria with regex
            string pattern = @"^(?!.*#).{14}$";  // Length 14, no '#' allowed
            if (Regex.IsMatch(finalPassword.ToString(), pattern))
            {
                lblGeneratedPassword.Text = $"Generated Password: {finalPassword}"; // Display the password
            }
            else
            {
                lblGeneratedPassword.Text = "Password generation failed. Try again."; // Display error message
            }
        }
    }
}
    
