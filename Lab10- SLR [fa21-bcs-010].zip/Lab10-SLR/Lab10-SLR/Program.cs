﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10_SLR
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Define the parsing table
            var parseTable = new Dictionary<string, Dictionary<string, string>>
            {
                { "0", new Dictionary<string, string> { { "begin", "S2" }, { "Program", "1" } } },
                { "1", new Dictionary<string, string> { { "$", "Accept" } } },
                { "2", new Dictionary<string, string> { { "int", "S3" } } },
                { "3", new Dictionary<string, string> { { "a", "S4" }, { "Var", "5" } } },
                { "4", new Dictionary<string, string> { { "=", "S6" } } },
                { "5", new Dictionary<string, string> { { ";", "R2" } } },
                { "6", new Dictionary<string, string> { { "5", "S7" }, { "Const", "8" } } },
                { "7", new Dictionary<string, string> { { ";", "R3" } } },
                { "8", new Dictionary<string, string> { { ";", "R1" } } }
            };

            // States for rules
            var rules = new Dictionary<int, (string lhs, int rhsCount)>
            {
                { 1, ("Program", 6) },
                { 2, ("DecS", 4) },
                { 3, ("AssS", 5) }
            };

            // Input and stack initialization
            Stack<string> stack = new Stack<string>();
            stack.Push("0");

            string input = "begin int a=5; $";
            var tokens = input.Split(' ');
            int pointer = 0;

            Console.WriteLine("Parsing started...\n");
            Console.WriteLine($"Input: {input}");

            while (true)
            {
                string currentState = stack.Peek();
                string currentToken = tokens[pointer];

                if (!parseTable.ContainsKey(currentState) || !parseTable[currentState].ContainsKey(currentToken))
                {
                    Console.WriteLine("Error: Unable to parse.");
                    break;
                }

                string action = parseTable[currentState][currentToken];

                if (action.StartsWith("S"))
                {
                    stack.Push(currentToken);
                    stack.Push(action.Substring(1));
                    pointer++;
                }
                else if (action.StartsWith("R"))
                {
                    int ruleIndex = int.Parse(action.Substring(1));
                    var (lhs, rhsCount) = rules[ruleIndex];

                    for (int i = 0; i < rhsCount * 2; i++) stack.Pop();
                    string newState = stack.Peek();

                    stack.Push(lhs);
                    stack.Push(parseTable[newState][lhs]);
                }
                else if (action == "Accept")
                {
                    Console.WriteLine("Parsing successful!");
                    break;
                }

                Console.WriteLine($"Stack: {string.Join(" ", stack)}");
            }
        
    }
    }
}
