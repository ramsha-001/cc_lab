﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace LabMid_Q2
{
    internal class Program
    {
        static void Main()
        {
            // Predefined values
            string registrationNumber = "fa21-bcs-010"; 
            string firstName = "Ramsha";               
            string lastName = "Kokab";                  
            string favoriteMovie = "Damsel";            

            // Extract required components based on the rules
            string[] parts = registrationNumber.Split('-');
            string digitsFromReg = parts[2].Substring(parts[2].Length - 2); 

            char secondLetterFirstName = firstName.Length > 1 ? firstName[1] : 'X';  // 'a' or 'X' if not available
            char secondLetterLastName = lastName.Length > 1 ? lastName[1] : 'Y';    // 'o' or 'Y' if not available
            string charsFromMovie = favoriteMovie.Length > 1 ? favoriteMovie.Substring(0, 2) : "ZZ"; // "Da" or "ZZ" if not available

            // Define a pool of special characters, excluding '#'
            string specialCharacters = "!@$%^&*()-_=+[]{};:'\",.<>?/|\\`~";

            // Generate random special character from the pool
            Random rand = new Random();
            char randomSpecialChar = specialCharacters[rand.Next(specialCharacters.Length)];

            // Create the initial password parts
            string password = $"{digitsFromReg}{secondLetterFirstName}{secondLetterLastName}{charsFromMovie}{randomSpecialChar}";

            // Fill the remaining length with random alphanumeric characters
            int remainingLength = 14 - password.Length;
            string alphanumeric = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

            StringBuilder finalPassword = new StringBuilder(password);
            for (int i = 0; i < remainingLength; i++)
            {
                finalPassword.Append(alphanumeric[rand.Next(alphanumeric.Length)]);
            }

            // Ensure password meets all criteria with regex
            string pattern = @"^(?!.*#).{14}$";  // Length 14, no '#' allowed
            if (Regex.IsMatch(finalPassword.ToString(), pattern))
            {
                Console.WriteLine($"Generated Password: {finalPassword}");
            }
            else
            {
                Console.WriteLine("Password generation failed. Try again.");
            }

            // Pause to keep the console open
            Console.WriteLine("Press Enter to exit...");
            Console.ReadLine();
        }
    }
}
